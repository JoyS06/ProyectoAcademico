main;
function main
    % Crear la interfaz gráfica
    trebol_robot_GUI();
end

function trebol_robot_GUI()
    f = figure('Name', 'Interfaz gráfica para trébol y brazo robótico', 'NumberTitle', 'off', 'Position', [50, 50, 1000, 600]);

    % Sliders para los parámetros del trébol
    uicontrol('Style', 'text', 'Position', [50, 530, 150, 20], 'String', 'Cantidad de hojas (n)');
    numHojasSlider = uicontrol('Style', 'slider', 'Position', [210, 530, 200, 20], 'Min', 1, 'Max', 12, 'Value', 8, 'Callback', @updatePlot);
    numHojasText = uicontrol('Style', 'text', 'Position', [420, 530, 50, 20], 'String', '8');

    uicontrol('Style', 'text', 'Position', [50, 480, 150, 20], 'String', 'Factor de escala');
    escalaSlider = uicontrol('Style', 'slider', 'Position', [210, 480, 200, 20], 'Min', 0.1, 'Max', 2, 'Value', 1, 'Callback', @updatePlot);
    escalaText = uicontrol('Style', 'text', 'Position', [420, 480, 50, 20], 'String', '1.33');

    uicontrol('Style', 'text', 'Position', [50, 430, 150, 20], 'String', 'Ángulo de rotación');
    rotacionSlider = uicontrol('Style', 'slider', 'Position', [210, 430, 200, 20], 'Min', 0, 'Max', 360, 'Value', 25, 'Callback', @updatePlot);
    rotacionText = uicontrol('Style', 'text', 'Position', [420, 430, 50, 20], 'String', '25');

    % Sliders para las longitudes de los eslabones del brazo robótico
    uicontrol('Style', 'text', 'Position', [50, 380, 150, 20], 'String', 'Longitud del eslabón 1 (l1)');
    l1Slider = uicontrol('Style', 'slider', 'Position', [210, 380, 200, 20], 'Min', 1, 'Max', 26, 'Value', 25, 'Callback', @updatePlot);
    l1Text = uicontrol('Style', 'text', 'Position', [420, 380, 50, 20], 'String', '15');

    uicontrol('Style', 'text', 'Position', [50, 330, 150, 20], 'String', 'Longitud del eslabón 2 (l2)');
    l2Slider = uicontrol('Style', 'slider', 'Position', [210, 330, 200, 20], 'Min', 1, 'Max', 20, 'Value', 15, 'Callback', @updatePlot);
    l2Text = uicontrol('Style', 'text', 'Position', [420, 330, 50, 20], 'String', '15');

    % Gráfica para mostrar el trébol y el brazo robótico
    ax = axes('Units', 'pixels', 'Position', [500, 100, 450, 450]);

    % Llamar a la función para actualizar la gráfica inicial
    updatePlot();

    function updatePlot(~, ~)
        % Obtener valores de los deslizadores
        num_hojas = round(get(numHojasSlider, 'Value'));
        escala = get(escalaSlider, 'Value');
        rotacion = get(rotacionSlider, 'Value');
        l1 = get(l1Slider, 'Value');
        l2 = get(l2Slider, 'Value');

        % Actualizar las etiquetas de texto
        set(numHojasText, 'String', num2str(num_hojas));
        set(escalaText, 'String', num2str(escala));
        set(rotacionText, 'String', num2str(rotacion));
        set(l1Text, 'String', num2str(l1));
        set(l2Text, 'String', num2str(l2));

        % Actualizar la gráfica del trébol y el brazo robótico
        plot_trebol_robot(ax, num_hojas, escala, rotacion, l1, l2);
    end
end

function plot_trebol_robot(ax, num_hojas, escala, rotacion, l1, l2)
    % Generar un vector de ángulos de 0 a 2*pi
    theta = linspace(0, 2*pi, 1000);

    % Calcular el radio para cada ángulo
    r = escala * 2 *(2 + sin(num_hojas * theta));

    % Convertir el ángulo de rotación a radianes
    rotacion_rad = deg2rad(rotacion);

    % Calcular las coordenadas x e y del trébol
    x = r .* cos(theta + rotacion_rad)+10;
    y = r .* sin(theta + rotacion_rad)+20;

    % Limpiar el gráfico
    cla(ax);

    % Configurar ejes
    axis(ax, 'equal');
    xlim(ax, [-2*escala, 12*escala]);
    ylim(ax, [-2*escala, 12*escala]);
    hold(ax, 'on');
    grid(ax, 'on');

    % Graficar el trébol
    plot(ax, x, y, 'b-', 'LineWidth', 2);

    % Bucle para animar los eslabones del brazo robótico
    for i = 1:length(theta)
        % Obtener la posición objetivo (x2, y2)
        x2 = x(i);
        y2 = y(i);
        
        % Calcular los ángulos utilizando cinemática inversa
        % Distancia desde el origen hasta el punto (x2, y2)
        d = sqrt(x2^2 + y2^2);

        % Chequear si el punto está alcanzable
        if d > (l1 + l2)
            disp('El punto está fuera del alcance del brazo robótico.');
            return;
        end

        % Ángulo del segundo eslabón (q2)
        q2 = acos((x2^2 + y2^2 - l1^2 - l2^2) / (2 * l1 * l2));

        % Ángulo del primer eslabón (q1)
        q1 = atan2(y2, x2) - atan2(l2 * sin(q2), l1 + l2 * cos(q2));

        % Calcular las coordenadas del final del primer eslabón (x1, y1)
        x1 = l1 * cos(q1);
        y1 = l1 * sin(q1);

        % Graficar los eslabones
        eslabon1 = line(ax, [0, x1], [0, y1], 'Color', 'b', 'LineWidth', 2);
        eslabon2 = line(ax, [x1, x2], [y1, y2], 'Color', 'r', 'LineWidth', 2);

        % Dibuja la trayectoria del final del eslabón 2
        plot(ax, x2, y2, 'g*');

        % Pausa para la animación
        pause(0.01);

        % Elimina las líneas de los eslabones para la próxima iteración
        if i < length(theta)
            delete(eslabon1);
            delete(eslabon2);
        end
    end

    % Mantener el gráfico
    hold(ax, 'off');
end

% Ejecutar el programa principal

